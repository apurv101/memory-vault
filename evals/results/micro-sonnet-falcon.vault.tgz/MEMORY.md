# Memory index — falcon

- [Falcon basics](project-falcon-basics.md) — codename, Postgres 16, Wednesday morning deploys
- [Falcon team & budget](project-falcon-team-budget.md) — Dana covers billing (Marco on leave), user owns gateway, $40k contractor budget/half
- [Falcon perf target](project-falcon-perf-target.md) — 200ms p95 on search, measured vs staging (eu-west-1)
