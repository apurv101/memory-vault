---
name: project-falcon-team-budget
description: Team ownership split and contractor budget for project Falcon
metadata:
  type: project
---

Marco owns the billing service, but is on parental leave starting 2026-04-17; Dana is covering billing-service ownership through roughly end of 2026 while he's out. The user owns the gateway. There's a $40k contractor budget for this half (H1 2026, as of 2026-03-02).

**Why:** Set at project kickoff for [[project-falcon-basics]]; ownership covered updated 2026-04-10 per Marco's leave.
**How to apply:** Route billing-service questions/changes to Dana (not Marco) until Marco returns from leave. Route gateway questions toward the user. Keep contractor spend suggestions within the $40k budget for the half.
