---
name: project-falcon-basics
description: Codename, stack, and deploy schedule for the internal API rewrite
metadata:
  type: project
---

The internal API rewrite kicked off 2026-03-02, internally codenamed "Falcon" — use this codename in docs. The service runs on Postgres 16 (migrated off Postgres 15 as of 2026-05-21). Deploys happen Wednesday mornings (moved from Friday afternoons as of 2026-05-21).

**Why:** Team decision at project kickoff for the codename/stack. Deploy schedule changed because Friday deploys were causing too many weekend incidents.
**How to apply:** Refer to the project as Falcon in any docs/PRs for this work. Assume Postgres 16 syntax/features. Schedule/plan deploy-related work around Wednesday morning deploy windows, not Friday.
