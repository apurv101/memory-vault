---
name: project-falcon-perf-target
description: p95 latency target for the Falcon search endpoint and where it's measured
metadata:
  type: project
---

Falcon committed to a 200ms p95 latency target on the search endpoint, per the 2026-04-10 perf review. This is measured against staging (not prod) for now. Staging runs in eu-west-1.

**Why:** Committed in the 2026-04-10 perf review for [[project-falcon-basics]].
**How to apply:** When discussing search endpoint performance or benchmarking, use the 200ms p95 staging target and eu-west-1 as the staging region. Flag if prod targets diverge from this once set.
